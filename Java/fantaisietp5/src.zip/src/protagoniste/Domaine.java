package protagoniste;

public enum Domaine {
	FEU, GLACE, TRANCHANT 
}
