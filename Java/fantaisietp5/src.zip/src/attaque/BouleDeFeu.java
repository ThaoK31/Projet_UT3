package attaque;

public class BouleDeFeu extends Feu{
	public BouleDeFeu(int nbBoulesDeFeu) {
		super(20,"Boules De Feu",nbBoulesDeFeu);
	}
}
