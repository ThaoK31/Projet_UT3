package attaque;

public abstract class Tranchant extends Pouvoir{
	public Tranchant(int pointDeDegat, String nom, int nbUtilisationPouvoir) {
		super(pointDeDegat,nom,nbUtilisationPouvoir);
	}
}
