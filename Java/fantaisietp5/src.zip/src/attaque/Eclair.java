package attaque;

public class Eclair extends Feu{
	public Eclair(int nbUtilisationPouvoir) {
		super(50,"Eclair",nbUtilisationPouvoir);
	}
}
