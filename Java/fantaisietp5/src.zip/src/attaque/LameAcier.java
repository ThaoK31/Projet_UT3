package attaque;

public class LameAcier extends Tranchant{
	public LameAcier(int nbUtilisationPouvoir) {
		super(50,"LameAcier",nbUtilisationPouvoir);
	}
}
