package attaque;

public class Lave extends Feu{
	public Lave(int nbUtilisationPouvoir) {
		super(80,"Lave",nbUtilisationPouvoir);
	}
}
