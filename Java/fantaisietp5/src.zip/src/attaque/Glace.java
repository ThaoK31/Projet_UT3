package attaque;

public abstract class Glace extends Pouvoir{
	public Glace(int pointDeDegat, String nom, int nbUtilisationPouvoir) {
		super(pointDeDegat,nom,nbUtilisationPouvoir);
	}
}
