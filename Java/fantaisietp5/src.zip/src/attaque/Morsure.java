package attaque;

public class Morsure extends Tranchant{
	public Morsure(int pointDeDegat) {
		super(pointDeDegat,"Morsure",100);
	}
}
