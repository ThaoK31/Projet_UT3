package attaque;

public class PicsDeGlace extends Glace{
	public PicsDeGlace(int nbUtilisationPouvoir) {
		super(50,"PicsDeGlace",nbUtilisationPouvoir);
	}
}
