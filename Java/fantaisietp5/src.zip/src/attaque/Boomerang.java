package attaque;

import protagoniste.ZoneDeCombat;

public class Boomerang extends Arme{
	public Boomerang() {
		super(20,"Boomerang", ZoneDeCombat.AERIEN, ZoneDeCombat.TERRESTRE);
	}
}
