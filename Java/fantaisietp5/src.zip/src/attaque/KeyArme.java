package attaque;

public class KeyArme extends Arme{
	public KeyArme(int forceMonstre) {
		super(forceMonstre, " ", null);
	}
}
