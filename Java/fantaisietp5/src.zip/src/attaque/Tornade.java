package attaque;

public class Tornade extends Glace{
	public Tornade(int nbUtilisationPouvoir) {
		super(50,"Tornade",nbUtilisationPouvoir);
	}
}
