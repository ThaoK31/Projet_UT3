package attaque;

import protagoniste.ZoneDeCombat;

public class LancePierre extends Arme{
	
	public LancePierre() {
		super(10,"LancePierre", ZoneDeCombat.AERIEN, ZoneDeCombat.TERRESTRE);
	}
}
