package jeu.cases;

public class CaseJardin {

}
